This zip file has a sample of one document each
